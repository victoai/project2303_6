package com.batis.paging;

import lombok.Data;

@Data
public class BoardDTO {
	int num;
	String content;
	String likenum;
	String image1;
}
