package com.batis.slide;

import lombok.Data;

@Data
public class SlideDTO {
	int num; //인덱스
	String content;
	String likenum;
	String image1;
}
