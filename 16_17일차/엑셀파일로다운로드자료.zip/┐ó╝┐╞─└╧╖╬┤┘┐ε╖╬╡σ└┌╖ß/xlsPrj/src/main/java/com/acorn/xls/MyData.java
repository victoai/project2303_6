package com.acorn.xls;

public class MyData {
    String  ID; 
	String  Name; 
	String  Age ;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	@Override
	public String toString() {
		return "MyData [ID=" + ID + ", Name=" + Name + ", Age=" + Age + "]";
	}
	public MyData(String iD, String name, String age) {
		super();
		ID = iD;
		Name = name;
		Age = age;
	}
	
	public MyData() {
		// TODO Auto-generated constructor stub
	}
	
}
