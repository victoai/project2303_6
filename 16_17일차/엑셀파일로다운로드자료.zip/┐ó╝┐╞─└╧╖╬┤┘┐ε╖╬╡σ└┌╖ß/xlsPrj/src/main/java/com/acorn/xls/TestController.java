package com.acorn.xls;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class TestController {
	

@ResponseBody
@RequestMapping(value = "/download", method = RequestMethod.GET)
public void downloadExcel(HttpServletResponse response) throws IOException {
    // 엑셀 파일 생성
    Workbook workbook = new XSSFWorkbook();
    Sheet sheet = workbook.createSheet("Data");

    // 데이터베이스에서 데이터 가져오기
   // List<MyData> dataList = myService.getDataList();
    List<MyData> dataList =new ArrayList<MyData>();
    
    dataList.add( new MyData("t1", "hong" , "25"));    
    dataList.add( new MyData("t2", "kim" , "25"));    
    dataList.add( new MyData("t3", "lee" , "25"));
    
    // 헤더 생성
    Row headerRow = sheet.createRow(0);
    headerRow.createCell(0).setCellValue("ID");
    headerRow.createCell(1).setCellValue("Name");
    headerRow.createCell(2).setCellValue("Age");

    // 데이터 생성
    int rowNum = 1;
    for (MyData data : dataList) {
        Row row = sheet.createRow(rowNum++);
        row.createCell(0).setCellValue(data.getID());
        row.createCell(1).setCellValue(data.getName());
        row.createCell(2).setCellValue(data.getAge());
    }

    // 엑셀 파일 다운로드
    response.setContentType("application/vnd.ms-excel");
    response.setHeader("Content-Disposition", "attachment; filename=mydata.xlsx");
    workbook.write(response.getOutputStream());
    workbook.close();
}

}
