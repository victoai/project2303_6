package aa.bb.vv;

import java.io.IOException;


//video 스트림 제공
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class VideoController {
    
    @RequestMapping("/streamVideo")
    public void streamVideo(HttpServletResponse response) throws IOException {
        String videoFilePath = "c:\\test\\upload\\k.mp4";   // 비디오파일위치 및 이름
        Path path = Paths.get(videoFilePath);
        
        // Content-Type 설정
        response.setContentType("video/mp4");
        
        // 파일 스트리밍
        Files.copy(path, response.getOutputStream());
        response.getOutputStream().flush();
    }
}
